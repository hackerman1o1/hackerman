this is a menu that lets you hack most games the games are listed down below.
if the exe does not load or open turn off you're antivirus and try agian if it still dont work try opening it with admin.
you need to open the menu before you open the game use at own risk.

ARK Survival Evolved.

counter strike 1 and 2.

fortnite.

mortal kombat x,11,1/12.

dying light 1 and 2.

fallout 76.

polygon.

rust.

war thunder.

phasmophobia.

will be updated soon